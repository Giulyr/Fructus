//
//  OnBoardingView.swift
//  Fructus
//
//  Created by Giulls on 30/12/21.
//

import SwiftUI

struct OnBoardingView: View {
    // MARK: - PROPERTIES
    // MARK: - BODY
    var body: some View {
        FruitCardView ()
    }
}
// MARK: - PREVIEW
struct OnBoardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnBoardingView()
    }
}
