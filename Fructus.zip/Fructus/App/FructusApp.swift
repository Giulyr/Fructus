    //
//  FructusApp.swift
//  Fructus
//
//  Created by Giulls on 30/12/21.
//  https://swiftuimasterclass.com

import SwiftUI

@main
struct FructusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
